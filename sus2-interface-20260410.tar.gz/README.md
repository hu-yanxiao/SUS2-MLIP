# SUS2 Interface for LAMMPS

## English

### 1. Overview

This repository provides SUS2 interface source files for LAMMPS.

Repository layout:

```text
ML-SUS2/       CPU interface source files
ML-SUS2-KK/    GPU/Kokkos interface source files
README.md      installation guide
```

Important notes:

1. `ML-SUS2` is the CPU-side SUS2 interface used in this repository.
2. `ML-SUS2-KK` is not a standalone package. It is a Kokkos/GPU override layer used together with `ML-SUS2`.
3. These folders contain the core interface source files. If your LAMMPS fork needs extra package-registration files such as `Install.sh`, package manifests, or additional CMake glue, keep those files from your fork and merge these source files into that package.
4. Some older or internal forks may still use the legacy package name `ML-SUS2-MTP`. If your tree still uses that name, replace `ML-SUS2` with `ML-SUS2-MTP` in the commands below.

### 2. Prerequisites

Start from a clean LAMMPS source tree:

```bash
git clone https://github.com/lammps/lammps.git
cd lammps
```

In this guide, the LAMMPS source tree is referred to as:

```bash
LAMMPS_ROOT=/path/to/lammps
```

Clone this SUS2 interface repository separately:

```bash
git clone <your-sus2-interface-repo-url> sus2-interface
cd sus2-interface
```

In this guide, the interface repository is referred to as:

```bash
INTERFACE_ROOT=/path/to/sus2-interface
```

### 3. How to Enable the Package

#### Old make

Run the following commands inside `LAMMPS_ROOT/src`:

```bash
make yes-ML-SUS2
make no-ML-SUS2
make package-status
```

Meaning:

- `make yes-ML-SUS2`: enable the package
- `make no-ML-SUS2`: disable the package
- `make package-status`: print the package enable/disable status

If your downstream fork still uses the legacy package name, use:

```bash
make yes-ML-SUS2-MTP
make no-ML-SUS2-MTP
```

#### CMake

Enable packages by listing them in the CMake command line.

CPU build example:

```bash
-D PKG_ML-SUS2=on
```

GPU build example:

```bash
-D PKG_ML-SUS2=on \
-D PKG_KOKKOS=on
```

If your fork still uses the legacy CMake key, replace `PKG_ML-SUS2` with `PKG_ML-SUS2-MTP`.

### 4. CPU Installation

Copy the CPU package into the LAMMPS `src` directory:

```bash
cd "$LAMMPS_ROOT/src"
rm -rf ML-SUS2
cp -r "$INTERFACE_ROOT/ML-SUS2" ./ML-SUS2
```

If your fork expects the legacy directory name, rename the directory to `ML-SUS2-MTP` instead.

Enable the package:

```bash
cd "$LAMMPS_ROOT/src"
make yes-ML-SUS2
```

Legacy-name fork:

```bash
make yes-ML-SUS2-MTP
```

Build with Intel compiler + Intel MPI:

```bash
cd "$LAMMPS_ROOT/src"
make intel_cpu_intelmpi -j 16
```

The generated binary is typically named:

```bash
lmp_intel_cpu_intelmpi
```

You can also try a generic MPI target if your toolchain is configured for it:

```bash
cd "$LAMMPS_ROOT/src"
make mpi -j 16
```

At runtime, the input syntax is:

```lammps
pair_style sus2mtp l3k3.mtp
pair_coeff * *
```

### 5. GPU Installation

The GPU/Kokkos interface depends on the CPU base package, so copy `ML-SUS2` first:

```bash
cd "$LAMMPS_ROOT/src"
rm -rf ML-SUS2
cp -r "$INTERFACE_ROOT/ML-SUS2" ./ML-SUS2
```

Then copy the Kokkos override files into `src/KOKKOS/`:

```bash
cd "$LAMMPS_ROOT/src"
cp "$INTERFACE_ROOT/ML-SUS2-KK/pair_sus2_mtp_kokkos.cpp" ./KOKKOS/
cp "$INTERFACE_ROOT/ML-SUS2-KK/pair_sus2_mtp_kokkos.h" ./KOKKOS/
```

Create a separate build directory:

```bash
cd "$LAMMPS_ROOT"
mkdir -p build-sus2kk
cd build-sus2kk
```

General CMake example:

```bash
cmake \
  -C ../cmake/presets/basic.cmake \
  -D BUILD_MPI=on \
  -D BUILD_OMP=off \
  -D PKG_ML-SUS2=on \
  -D PKG_KOKKOS=on \
  -D Kokkos_ENABLE_SERIAL=on \
  -D Kokkos_ENABLE_CUDA=on \
  -D Kokkos_ENABLE_CUDA_LAMBDA=on \
  -D KOKKOS_PREC=double \
  -D CMAKE_CXX_COMPILER=mpicxx \
  -D CMAKE_BUILD_TYPE=RelWithDebInfo \
  -D WITH_JPEG=OFF \
  -D WITH_PNG=OFF \
  ../cmake
```

If your fork still uses the legacy key, change `PKG_ML-SUS2=on` to `PKG_ML-SUS2-MTP=on`.

If you know your GPU architecture, set it explicitly. Example for A100:

```bash
-D Kokkos_ARCH_AMPERE80=on
```

Build:

```bash
cmake --build . -j 16
```

The generated binary is usually:

```bash
$LAMMPS_ROOT/build-sus2kk/lmp
```

At runtime, the input syntax is:

```lammps
pair_style sus2mtp/kk fitted.mtp chunksize 129600
pair_coeff * *
```

Typical run command:

```bash
./lmp -k on g 1 -sf kk -pk kokkos newton on neigh half comm device -in in.lmp
```

### 6. Quick Checklist

CPU:

1. Clone LAMMPS.
2. Copy `ML-SUS2` into `LAMMPS_ROOT/src/`.
3. Enable the package with `make yes-ML-SUS2`.
4. Build with `make intel_cpu_intelmpi` or another MPI target.

GPU:

1. Clone LAMMPS.
2. Copy `ML-SUS2` into `LAMMPS_ROOT/src/`.
3. Copy `ML-SUS2-KK` files into `LAMMPS_ROOT/src/KOKKOS/`.
4. Enable `PKG_ML-SUS2` and `PKG_KOKKOS` in CMake.
5. Build with `cmake --build . -j`.

### 7. Troubleshooting

`Unknown package ML-SUS2`

- Your downstream tree may still use the legacy package name.
- Try `ML-SUS2-MTP` instead.
- Also verify that your tree includes the package registration/build glue expected by your fork.

GPU build cannot find `pair_sus2_mtp.h`

- You copied `ML-SUS2-KK`, but you did not copy the CPU base package first.

`mpicxx` not found

- Load your MPI toolchain first, or set `CMAKE_CXX_COMPILER` explicitly.

`std::filesystem` link errors in old make

- Your compiler may require `-lstdc++fs`.

## 中文

### 1. 概述

本仓库提供 LAMMPS 的 SUS2 接口源码。

仓库内容如下：

```text
ML-SUS2/       CPU 版接口源码
ML-SUS2-KK/    GPU/Kokkos 版接口源码
README.md      安装说明
```

需要注意：

1. `ML-SUS2` 是本仓库使用的 CPU 版 SUS2 接口名称。
2. `ML-SUS2-KK` 不是独立 package，而是配合 `ML-SUS2` 使用的 Kokkos/GPU 覆盖层。
3. 这两个目录提供的是核心接口源码。如果你的 LAMMPS fork 还需要 `Install.sh`、package 清单文件或额外的 CMake glue，请保留你自己 fork 中的这些文件，再把这里的源码合并进去。
4. 某些较旧或内部使用的 fork 仍可能使用旧包名 `ML-SUS2-MTP`。如果你的代码树仍使用旧名字，请把下面命令中的 `ML-SUS2` 替换成 `ML-SUS2-MTP`。

### 2. 前置条件

建议先准备一份干净的 LAMMPS 源码树：

```bash
git clone https://github.com/lammps/lammps.git
cd lammps
```

下面统一把这份源码树记作：

```bash
LAMMPS_ROOT=/path/to/lammps
```

再单独下载本接口仓库：

```bash
git clone <your-sus2-interface-repo-url> sus2-interface
cd sus2-interface
```

下面统一把接口仓库记作：

```bash
INTERFACE_ROOT=/path/to/sus2-interface
```

### 3. 如何开启 Package

#### old make 方式

在 `LAMMPS_ROOT/src` 目录下执行：

```bash
make yes-ML-SUS2
make no-ML-SUS2
make package-status
```

含义如下：

- `make yes-ML-SUS2`：开启 package
- `make no-ML-SUS2`：关闭 package
- `make package-status`：查看 package 当前状态

如果你的下游 fork 仍使用旧包名，则改用：

```bash
make yes-ML-SUS2-MTP
make no-ML-SUS2-MTP
```

#### CMake 方式

对于 CMake 构建，通常通过在命令行中列表化写出 `-D PKG_...=on` 来开启 package。

CPU 示例：

```bash
-D PKG_ML-SUS2=on
```

GPU 示例：

```bash
-D PKG_ML-SUS2=on \
-D PKG_KOKKOS=on
```

如果你的 fork 仍使用旧的 CMake key，请把 `PKG_ML-SUS2` 改成 `PKG_ML-SUS2-MTP`。

### 4. CPU 安装方法

先把 CPU 包复制到 LAMMPS 的 `src` 目录：

```bash
cd "$LAMMPS_ROOT/src"
rm -rf ML-SUS2
cp -r "$INTERFACE_ROOT/ML-SUS2" ./ML-SUS2
```

如果你的 fork 仍要求旧目录名，请把目录名改成 `ML-SUS2-MTP`。

然后开启 package：

```bash
cd "$LAMMPS_ROOT/src"
make yes-ML-SUS2
```

旧包名 fork：

```bash
make yes-ML-SUS2-MTP
```

如果你使用 Intel 编译器 + Intel MPI，可直接编译：

```bash
cd "$LAMMPS_ROOT/src"
make intel_cpu_intelmpi -j 16
```

生成的可执行文件通常为：

```bash
lmp_intel_cpu_intelmpi
```

如果你使用的是通用 MPI 工具链，也可以尝试：

```bash
cd "$LAMMPS_ROOT/src"
make mpi -j 16
```

是否能直接成功，取决于你的编译器、MPI 环境以及 `MAKE/OPTIONS/Makefile.mpi` 配置。

运行时，输入脚本的写法为：

```lammps
pair_style sus2mtp l3k3.mtp
pair_coeff * *
```

### 5. GPU 安装方法

GPU/Kokkos 接口依赖 CPU 基础包，因此第一步仍然是先复制 `ML-SUS2`：

```bash
cd "$LAMMPS_ROOT/src"
rm -rf ML-SUS2
cp -r "$INTERFACE_ROOT/ML-SUS2" ./ML-SUS2
```

然后把 Kokkos 覆盖文件复制到 `src/KOKKOS/`：

```bash
cd "$LAMMPS_ROOT/src"
cp "$INTERFACE_ROOT/ML-SUS2-KK/pair_sus2_mtp_kokkos.cpp" ./KOKKOS/
cp "$INTERFACE_ROOT/ML-SUS2-KK/pair_sus2_mtp_kokkos.h" ./KOKKOS/
```

建议单独建立一个 build 目录：

```bash
cd "$LAMMPS_ROOT"
mkdir -p build-sus2kk
cd build-sus2kk
```

通用 CMake 示例：

```bash
cmake \
  -C ../cmake/presets/basic.cmake \
  -D BUILD_MPI=on \
  -D BUILD_OMP=off \
  -D PKG_ML-SUS2=on \
  -D PKG_KOKKOS=on \
  -D Kokkos_ENABLE_SERIAL=on \
  -D Kokkos_ENABLE_CUDA=on \
  -D Kokkos_ENABLE_CUDA_LAMBDA=on \
  -D KOKKOS_PREC=double \
  -D CMAKE_CXX_COMPILER=mpicxx \
  -D CMAKE_BUILD_TYPE=RelWithDebInfo \
  -D WITH_JPEG=OFF \
  -D WITH_PNG=OFF \
  ../cmake
```

如果你的 fork 仍使用旧 key，请把 `PKG_ML-SUS2=on` 改成 `PKG_ML-SUS2-MTP=on`。

如果你知道自己的 GPU 架构，建议显式指定。例如 A100：

```bash
-D Kokkos_ARCH_AMPERE80=on
```

编译命令：

```bash
cmake --build . -j 16
```

生成的二进制通常为：

```bash
$LAMMPS_ROOT/build-sus2kk/lmp
```

运行时，输入脚本的写法为：

```lammps
pair_style sus2mtp/kk fitted.mtp chunksize 129600
pair_coeff * *
```

典型运行命令：

```bash
./lmp -k on g 1 -sf kk -pk kokkos newton on neigh half comm device -in in.lmp
```

### 6. 快速检查清单

CPU：

1. 先 clone LAMMPS。
2. 把 `ML-SUS2` 放进 `LAMMPS_ROOT/src/`。
3. 用 `make yes-ML-SUS2` 开启 package。
4. 用 `make intel_cpu_intelmpi` 或其他 MPI 目标编译。

GPU：

1. 先 clone LAMMPS。
2. 先把 `ML-SUS2` 放进 `LAMMPS_ROOT/src/`。
3. 再把 `ML-SUS2-KK` 两个文件放进 `LAMMPS_ROOT/src/KOKKOS/`。
4. 在 CMake 中开启 `PKG_ML-SUS2` 和 `PKG_KOKKOS`。
5. 用 `cmake --build . -j` 编译。

### 7. 常见问题

`Unknown package ML-SUS2`

- 你的下游代码树可能仍使用旧包名。
- 可以尝试改用 `ML-SUS2-MTP`。
- 也请确认你的代码树包含该 fork 期望的 package 注册和构建脚本。

GPU 编译时报找不到 `pair_sus2_mtp.h`

- 说明你只复制了 `ML-SUS2-KK`，但没有先复制 CPU 基础包 `ML-SUS2`。

`mpicxx` 找不到

- 请先加载 MPI 工具链，或者显式设置 `CMAKE_CXX_COMPILER`。

old make 报 `std::filesystem` 链接错误

- 你的编译器可能需要额外链接 `-lstdc++fs`。
